/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    gpio.c
  * @brief   This file provides code for the configuration
  *          of all used GPIO pins.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "gpio.h"

/* USER CODE BEGIN 0 */
#include "adc.h"
#include <stdio.h>
/* USER CODE END 0 */

/*----------------------------------------------------------------------------*/
/* Configure GPIO                                                             */
/*----------------------------------------------------------------------------*/
/* USER CODE BEGIN 1 */

/* USER CODE END 1 */

/** Configure pins as
        * Analog
        * Input
        * Output
        * EVENT_OUT
        * EXTI
*/
void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, d0_Pin|d1_Pin|d2_Pin|d3_Pin
                          |d4_Pin|d5_Pin|d6_Pin|d7_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, ro_Pin|GPIO_PIN_5, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, en_Pin|rs_Pin|rw_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : d0_Pin d1_Pin d2_Pin d3_Pin
                           d4_Pin d5_Pin d6_Pin d7_Pin */
  GPIO_InitStruct.Pin = d0_Pin|d1_Pin|d2_Pin|d3_Pin
                          |d4_Pin|d5_Pin|d6_Pin|d7_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : ro_Pin PA5 */
  GPIO_InitStruct.Pin = ro_Pin|GPIO_PIN_5;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PB2 */
  GPIO_InitStruct.Pin = GPIO_PIN_2;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : en_Pin rs_Pin rw_Pin */
  GPIO_InitStruct.Pin = en_Pin|rs_Pin|rw_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI2_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI2_IRQn);

}

/* USER CODE BEGIN 2 */
void lcdinit(void)
{

//function set
	//HAL_GPIO_WritePin(GPIOB, rs_Pin|rw_Pin, GPIO_PIN_RESET);
	GPIOB->BSRR = (rs_Pin|rw_Pin)<<16;
	HAL_Delay(1);
	//HAL_GPIO_WritePin(GPIOB, en_Pin, GPIO_PIN_SET);
	GPIOB->BSRR = (en_Pin);
	//HAL_Delay(1);
	//GPIOA->BSRR |= 0b11 (GPIOA->BSRR)&0xf0;
	//HAL_GPIO_WritePin(GPIOC, d0_Pin|d1_Pin|d6_Pin|d7_Pin, GPIO_PIN_RESET);
	//GPIOC->BSRR = (d0_Pin|d1_Pin|d6_Pin|d7_Pin)<<16;
	//HAL_GPIO_WritePin(GPIOC, d5_Pin|d4_Pin|d2_Pin|d3_Pin, GPIO_PIN_SET);
	//GPIOC->BSRR = (d5_Pin|d4_Pin|d2_Pin|d3_Pin);
	GPIOC->ODR = 0x3c;
	HAL_Delay(1);
	//HAL_GPIO_WritePin(GPIOB, en_Pin, GPIO_PIN_RESET);
	GPIOB->BSRR = (en_Pin)<<16;
	//HAL_Delay(1);


}

void dspon(void)
{
	//disp on
		//HAL_GPIO_WritePin(GPIOB, rs_Pin|rw_Pin, GPIO_PIN_RESET);
		GPIOB->BSRR = (rs_Pin|rw_Pin)<<16;

		HAL_Delay(1);
		//HAL_GPIO_WritePin(GPIOB, en_Pin, GPIO_PIN_SET);
		GPIOB->BSRR = (en_Pin);
		//HAL_Delay(1);
		//GPIOA->BSRR |= 0b11 (GPIOA->BSRR)&0xf0;
		//HAL_GPIO_WritePin(GPIOC, d5_Pin|d4_Pin|d6_Pin|d7_Pin, GPIO_PIN_RESET);
		//HAL_GPIO_WritePin(GPIOC, d2_Pin|d0_Pin|d1_Pin|d3_Pin, GPIO_PIN_SET);
		GPIOC->ODR = 0xc;
		HAL_Delay(1);
		//HAL_GPIO_WritePin(GPIOB, en_Pin, GPIO_PIN_RESET);
		GPIOB->BSRR = (en_Pin)<<16;
		//HAL_Delay(1);

}

void clrdsp(void)
{
	//disp on
		//HAL_GPIO_WritePin(GPIOB, rs_Pin|rw_Pin, GPIO_PIN_RESET);
		GPIOB->BSRR = (rs_Pin|rw_Pin)<<16;
		HAL_Delay(1);
		//HAL_GPIO_WritePin(GPIOB, en_Pin, GPIO_PIN_SET);
		GPIOB->BSRR = (en_Pin);
		//HAL_Delay(1);
		//GPIOA->BSRR |= 0b11 (GPIOA->BSRR)&0xf0;
		//HAL_GPIO_WritePin(GPIOC, d2_Pin|d5_Pin|d4_Pin|d6_Pin|d7_Pin|d1_Pin|d3_Pin, GPIO_PIN_RESET);
		//HAL_GPIO_WritePin(GPIOC, d0_Pin, GPIO_PIN_SET);
		GPIOC->ODR = 0x1;
		HAL_Delay(1);
		//HAL_GPIO_WritePin(GPIOB, en_Pin, GPIO_PIN_RESET);
		GPIOB->BSRR = (en_Pin)<<16;
		//HAL_Delay(1);
}

void setCharacter(uint8_t pos, uint8_t data)
{


	//HAL_GPIO_WritePin(GPIOB, rs_Pin|rw_Pin, GPIO_PIN_RESET);
	GPIOB->BSRR = (rs_Pin|rw_Pin)<<16;
	HAL_Delay(1);
	//HAL_GPIO_WritePin(GPIOB, en_Pin, GPIO_PIN_SET);
	GPIOB->BSRR = (en_Pin);
	//HAL_Delay(1);
	//GPIOC->BSRR = 0xff<<16;//reset
	if(pos>0xf)
	{
		GPIOC->ODR = (uint32_t)(pos-16)|(0x3<<6);//set
	}else{
		GPIOC->ODR = (uint32_t)(pos)|(0x1<<7);//set
	}

	HAL_Delay(1);
	//HAL_GPIO_WritePin(GPIOB, en_Pin, GPIO_PIN_RESET);
	GPIOB->BSRR = (en_Pin)<<16;
	HAL_Delay(1);

	//HAL_GPIO_WritePin(GPIOB, rs_Pin, GPIO_PIN_SET);
	//HAL_GPIO_WritePin(GPIOB, rw_Pin, GPIO_PIN_RESET);
	GPIOB->BSRR = (rw_Pin)<<16;
	GPIOB->BSRR = (rs_Pin);
	HAL_Delay(1);
	//HAL_GPIO_WritePin(GPIOB, en_Pin, GPIO_PIN_SET);
	GPIOB->BSRR = (en_Pin);
	//HAL_Delay(1);
	//GPIOC->BSRR = 0xff<<16;//reset
	GPIOC->ODR = (uint32_t)data;//set
	HAL_Delay(1);
	//HAL_GPIO_WritePin(GPIOB, en_Pin, GPIO_PIN_RESET);
	GPIOB->BSRR = (en_Pin)<<16;
	HAL_Delay(1);


}
uint8_t dsp0[20]="aaaabbbbccccdddd";
uint8_t dsp1[20]="eeeeffffgggghhhh";
uint8_t *pdsp0=dsp0;
void printdsp(void)
{
	//sprintf(dsp0,"adc:%d",getadcdata(0));
	//pdsp0 = "aaaa           ";
	for(uint8_t i=0;i<16;i++)
	{
		setCharacter(i, dsp0[i]);
	}
	for(uint8_t j=16;j<32;j++)
	{
		setCharacter(j, dsp1[j-16]);
	}
}
/* USER CODE END 2 */
